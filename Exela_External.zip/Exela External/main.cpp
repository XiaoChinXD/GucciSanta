﻿#include "blabla/include.h"
#include "driver/driver.h"
#include "sdk/cheats.h"
#include "auth/auth.hpp"
#include "blabla/skStr.h"
#include "blabla/download.h"
#include <locale>
#include <iostream>
#include <windows.h>
#include <string>
#include <sstream>
#include <winerror.h>
#include <ntstatus.h>
#include <bcrypt.h>
#include <wininet.h>
#include <xstring>
#include <vector>
#include <fstream>
#include <chrono>
#include <codecvt>
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include "blabla/protect.h"
#include "discord.hpp"
Discord* g_Discord;

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "libcurl.lib")
#pragma comment(lib, "discord-rpc.lib")

#pragma optimize("", off)

using namespace KeyAuth;
std::string name = "vac"; // application name. right above the blurred text aka the secret on the licenses tab among other tabs
std::string ownerid = "d"; // ownerid, found in account settings. click your profile picture on top right of dashboard and then account settings.
std::string secret = "d"; // app secret, the blurred text on licenses tab and other tabs
std::string version = "2.0"; // leave alone unless you've changed version on website
std::string url = skCrypt("https://keyauth.win/api/1.2/").decrypt(); // change if you're self-hosting

api KeyAuthApp(name, ownerid, secret, version, url);

using namespace std;
namespace fs = std::filesystem;

std::string tm_to_readable_time(tm ctx) {
    char buffer[80];

    strftime(buffer, sizeof(buffer), " %d/%m/%y", &ctx);

    return std::string(buffer);
}

static std::time_t string_to_timet(std::string timestamp) {
    auto cv = strtol(timestamp.c_str(), NULL, 10);

    return (time_t)cv;
}

static std::tm timet_to_tm(time_t timestamp) {
    std::tm context;

    localtime_s(&context, &timestamp);

    return context;
}


DWORD GetProcessID(const std::wstring processName)
{
    PROCESSENTRY32 processInfo;
    processInfo.dwSize = sizeof(processInfo);

    HANDLE processesSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    if (processesSnapshot == INVALID_HANDLE_VALUE)
    {
        return 0;
    }

    Process32First(processesSnapshot, &processInfo);
    if (!processName.compare(processInfo.szExeFile))
    {
        CloseHandle(processesSnapshot);
        return processInfo.th32ProcessID;
    }

    while (Process32Next(processesSnapshot, &processInfo))
    {
        if (!processName.compare(processInfo.szExeFile))
        {
            CloseHandle(processesSnapshot);
            return processInfo.th32ProcessID;
        }
    }

    CloseHandle(processesSnapshot);
    return 0;
}


auto get_process_wnd(uint32_t pid) -> HWND
{
    std::pair<HWND, uint32_t> params = { 0, pid };
    BOOL bResult = EnumWindows([](HWND hwnd, LPARAM lParam) -> BOOL {
        auto pParams = (std::pair<HWND, uint32_t>*)(lParam);
        uint32_t processId = 0;

        if (GetWindowThreadProcessId(hwnd, reinterpret_cast<LPDWORD>(&processId)) && processId == pParams->second) {
            SetLastError((uint32_t)-1);
            pParams->first = hwnd;
            return FALSE;
        }

        return TRUE;

        }, (LPARAM)&params);

    if (!bResult && GetLastError() == -1 && params.first)
        return params.first;

    return NULL;
}
string hwidcheck = DownloadString(XorStr("https://raw.githubusercontent.com/amliva/valo-auth/main/keys.txt"));


std::string generateRandomName(int length) {
    std::string name;
    static const char charset[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    for (int i = 0; i < length; ++i) {
        int index = rand() % (sizeof(charset) - 1);
        name += charset[index];
    }

    return name;
}


std::string tm_to_readable_time(tm ctx);
static std::time_t string_to_timet(std::string timestamp);
static std::tm timet_to_tm(time_t timestamp);
const std::string compilation_date = (std::string)skCrypt(__DATE__);
const std::string compilation_time = (std::string)skCrypt(__TIME__);
size_t wclbcks(void* contents, size_t size, size_t nmemb, std::string* response) {
    size_t totalSize = size * nmemb;
    response->append((char*)contents, totalSize);
    return totalSize;
}


std::string encrypt(const std::string& input, const std::string& key)
{
    std::string output = input;
    for (size_t i = 0; i < input.length(); ++i)
    {
        output[i] = input[i] ^ key[i % key.length()];
    }
    return output;
}

std::string decrypt(const std::string& input, const std::string& key)
{
    std::string output = input;
    size_t length = input.length();
    size_t keyLength = key.length();

    for (size_t i = 0; i < length; ++i) {
        output[i] = input[i] ^ key[i % keyLength];
    }

    return output;
}

void cheat()
{

    std::string keyyyyyy = "0123456789";

    std::string activecheat = "[+] Cheat active menu off/on key : Insert.";
    std::string notfounddrver = "[-] Driver not found. Exiting..";
    std::string ntfoundgame = "[-] Game not found please press F1 in the Lobby..";

    std::string encryptedactv = encrypt(activecheat, keyyyyyy);
    std::string encryptedntfnddv = encrypt(notfounddrver, keyyyyyy);
    std::string encryptedntfondgme = encrypt(ntfoundgame, keyyyyyy);

  /*  if (lexemvemem::lexemvefind_driver()) {
        system("cls");
    }
    else {
        system("cls");
        system("color c");
        for (char& c : notfounddrver) {
            std::cout << c;
            std::this_thread::sleep_for(std::chrono::milliseconds(50)); // Her karakterin arasında 50 milisaniye bekleyin
        }
        Sleep(3000);
        exit(0);
    }*/

    if (lexemvemem::lexemvefind_process(L"TestEnvironmentD3D11.exe")) {
     /*   lexemvevirtualaddy = get_guarded_reg();
        check::guard = lexemvevirtualaddy;
        base = lexemvemem::lexemvefind_image();*/
        system("cls");
        for (char& c : activecheat) {
            std::cout << c;
            std::this_thread::sleep_for(std::chrono::milliseconds(50)); // Her karakterin arasında 50 milisaniye bekleyin
        }

        g_Discord->Initialize();
        g_Discord->Update();
        LAGMMEEE::LASTRTC();
    }
    else {
        system("cls");
        system("color c");
        for (char& c : ntfoundgame) {
            std::cout << c;
            std::this_thread::sleep_for(std::chrono::milliseconds(50)); // Her karakterin arasında 50 milisaniye bekleyin
        }
        Sleep(2000);
        exit(0);
    }
}

bool SetClipboard(const std::string& data) {

    auto size = data.size() + 1;
    auto pGlobal = GlobalAlloc(GMEM_MOVEABLE, size);

    if (!pGlobal) {

        return false;
    }

    OpenClipboard(0);
    EmptyClipboard();

    auto pLock = GlobalLock(pGlobal);

    if (!pLock) {
        CloseClipboard();
        return false;
    }

    CopyMemory(pLock, data.c_str(), size);

    GlobalUnlock(pGlobal);

    SetClipboardData(CF_TEXT, pGlobal);

    CloseClipboard();

    GlobalFree(pGlobal);

    return true;
}

int main(HWND, UINT, WPARAM, LPARAM);

int main(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    GlobalAddAtomA("qwertyssddsjdfkjd");
    std::string randomName = RandomString(70);
    SetConsoleTitleA(randomName.c_str());
    Sleep(1500);
    Protecion();
    BOOL result;
    if (GlobalFindAtomA("qwertyssddsjdfkjd") == 0)
    {
        exit(0);
    }
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &result); //Get a handle to our current process and send our result to the our boolean.
    if (result || result == 1) //Check to see if our result is true.
    {
        exit(0);
    }
    SetLastError(0); //Set last error to 0 so it won't conflict with our check.
    OutputDebugStringA("Using a debugger?"); //Send a little message to the debugger.
    if (GetLastError() != 0) //If the message passed without error (Meaning it was sent to the debugger)
    {
        exit(0);
    }
    Protecion();

    if (GlobalFindAtomA("qwertyssddsjdfkjd") == 0)
    {
        exit(0);
    }

    CheckRemoteDebuggerPresent(GetCurrentProcess(), &result); //Get a handle to our current process and send our result to the our boolean.
    if (result || result == 1) //Check to see if our result is true.
    {
        exit(0);
    }

    SetLastError(0); //Set last error to 0 so it won't conflict with our check.
    OutputDebugStringA("Using a debugger?"); //Send a little message to the debugger.
    if (GetLastError() != 0) //If the message passed without error (Meaning it was sent to the debugger)
    {
        exit(0);
    }

    if (lexemvemem::lexemvefind_driver()) {
        goto Func;
    }
    else {
        //lexemvemmap_driver();
        Sleep(1);
        goto Func;
    }

Func:
    system("cls");

    std::cout << "\n Please open the game and press F1 in the Lobby..";

    while (true) {

        if (GetAsyncKeyState(VK_F1)) {

            break;
        }
    }

    lexemvemem::lexemvefind_process(L"TestEnvironmentD3D11.exe");

    if (lexemvemem::lexemveprocess_id != 0)
    {

        Sleep(1000);
        cheat();
    }
}



#pragma optimize("", on)