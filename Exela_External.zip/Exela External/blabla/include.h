#include <thread>
#include <cstdlib>
#include <tchar.h>
#include <urlmon.h>
#include <string>
#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <fstream>
#include <vector>
#include <filesystem>
#include <dwmapi.h>
#include <psapi.h>
#include <math.h>
#include "../drectx/d3dx9.h"
#include "../emgui/imgui.h"
#include "utils.hpp"

#pragma comment (lib, "dwmapi.lib")
#pragma comment (lib, "d3d9.lib")
#pragma comment(lib, "urlmon.lib")
