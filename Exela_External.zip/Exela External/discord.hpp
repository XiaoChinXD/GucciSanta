#pragma once
#include <discord_register.h>
#include <discord_rpc.h>
#include <Windows.h>

class Discord {
public:
	void Initialize();
	void Update();
};