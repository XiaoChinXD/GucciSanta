﻿#include "../main.h"
#include "../blabla/icons.h"
#include "../blabla/fonthelper.h"
#include "../blabla/Images.h"
#include "imgui.h"
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui_internal.h"
#include "../backends/imgui_impl_dx9.h"
#include "../backends/imgui_impl_win32.h"
#include <d3d9.h>
#include <tchar.h>
#include <vector>
#include <random>
#include <math.h>
#include "byte.h"
#include "elements.h"
int radartype = 0;

using namespace ImGui;

enum heads {
    HEAD_1,
    HEAD_2,
    HEAD_3,
    HEAD_4
};

namespace fonts {
    ImFont* medium;
    ImFont* semibold;

    ImFont* logo;
}


static heads head_selected = HEAD_1;
static bool checkbox[1]{};

void bubble()
{
    auto draw = ImGui::GetWindowDrawList();

    auto pos = ImGui::GetWindowPos();
    auto size = ImGui::GetWindowSize();
    draw->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + 51), ImColor(24, 24, 24), 9.0f, ImDrawFlags_RoundCornersTop);
    draw->AddRectFilledMultiColorRounded(pos, ImVec2(pos.x + 55, pos.y + 51), ImColor(1.0f, 1.0f, 1.0f, 0.00f), ImColor(1.0f, 1.0f, 1.0f, 0.05f), ImColor(1.0f, 1.0f, 1.0f, 0.00f), ImColor(1.0f, 1.0f, 1.0f, 0.00f), ImColor(1.0f, 1.0f, 1.0f, 0.05f), 9.0f, ImDrawFlags_RoundCornersTopLeft);

    draw->AddText(fonts::logo, 17.0f, ImVec2(pos.x + 25, pos.y + 17), ImColor(192, 203, 229), "A");
    draw->AddText(fonts::semibold, 17.0f, ImVec2(pos.x + 49, pos.y + 18), ImColor(192, 203, 229), "Exela");

    ImGui::SetCursorPos({ 125, 19 });
    ImGui::BeginGroup(); {
        if (elements::tab("Visuals", head_selected == HEAD_1)) head_selected = HEAD_1;
        ImGui::SameLine();
        if (elements::tab("Aimbot", head_selected == HEAD_2)) head_selected = HEAD_2;
        ImGui::SameLine();
        if (elements::tab("Colors", head_selected == HEAD_3)) head_selected = HEAD_3;
        ImGui::SameLine();
        if (elements::tab("Config", head_selected == HEAD_4)) head_selected = HEAD_4;
    }
    ImGui::EndGroup();

    switch (head_selected) {
    case HEAD_1:
        draw->AddText(fonts::medium, 14.0f, ImVec2(pos.x + 25, pos.y + 60), ImColor(1.0f, 1.0f, 1.0f, 0.6f), "ESP Settings");

        ImGui::SetCursorPos({ 25, 85 });
        ImGui::BeginChild("##container", ImVec2(240, 350), false, ImGuiWindowFlags_NoScrollbar); {
            ImGui::Combo("Box Settings", &config.esptype, type, IM_ARRAYSIZE(type));
            ImGui::Checkbox("Box ESP", &config.player_box);
            ImGui::Checkbox("Head Box", &config.circlehead);
            ImGui::Checkbox("Skeleton Esp", &config.player_skeleton);
            ImGui::Checkbox("Distance ESP", &config.player_distance);
            ImGui::Checkbox("Healthbar", &config.player_healthbar);
            ImGui::Checkbox("Esp Line", &config.player_snapline);
        }
        ImGui::EndChild();

        ImGui::SetCursorPos({ 285, 85 });
        ImGui::BeginChild("##container2", ImVec2(240, 350), false, ImGuiWindowFlags_NoScrollbar); {
            ImGui::Checkbox("Distance Control", &config.distancecontrol);
            ImGui::SliderInt("Max Distance", &config.max_distance, 10, 200);
            ImGui::Checkbox("Agent Names", &config.agentnames);
            ImGui::Checkbox("Radar ESP", &config.radar);
            ImGui::Combo("Radar Type", &radartype, radart, IM_ARRAYSIZE(radart));
            ImGui::Checkbox("Ignore Dormant", &config.player_ignore_dormant);
        }
        ImGui::EndChild();
        break;
    
    case HEAD_2:
        draw->AddText(fonts::medium, 14.0f, ImVec2(pos.x + 25, pos.y + 60), ImColor(1.0f, 1.0f, 1.0f, 0.6f), "Aimbot Settings");
        ImGui::SetCursorPos({ 25, 85 });
        ImGui::BeginChild("##container3", ImVec2(240, 350), false, ImGuiWindowFlags_NoScrollbar); {
            ImGui::Checkbox("Aimbot", &config.aimenable);
            ImGui::Checkbox("Visible Check", &config.visiblecheck);
            ImGui::Checkbox("Draw Fov", &config.aimbot_draw_fov);
            ImGui::Checkbox("RCS", &config.rcs);
        }
        ImGui::EndChild();

        ImGui::SetCursorPos({ 285, 85 });
        ImGui::BeginChild("##container4", ImVec2(240, 350), false, ImGuiWindowFlags_NoScrollbar); {
            ImGui::Combo("Key", &config.aimbotkey, optKey, IM_ARRAYSIZE(optKey));
            ImGui::Combo("Target Bone", &config.aimboness, aimbone, IM_ARRAYSIZE(aimbone));
            ImGui::SliderFloat("Fov", &config.aimbot_fov, 10.f, 400.f, "%.f");
            ImGui::SliderFloat("Smooth", &config.aimbot_smooth, 1.f, 20.f, "%.f");

        }
        ImGui::EndChild();
        break;

    case HEAD_3:
        draw->AddText(fonts::medium, 14.0f, ImVec2(pos.x + 25, pos.y + 60), ImColor(1.0f, 1.0f, 1.0f, 0.6f), "Color Settings");
        ImGui::SetCursorPos({ 25, 85 });
        ImGui::BeginChild("##container5", ImVec2(240, 350), false, ImGuiWindowFlags_NoScrollbar); {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1, 0, 0, 0));
            ImGui::ColorPicker4("Esp Color", (float*)&config.espcolor);
            ImGui::ColorPicker4("Esp Line Color", (float*)&config.snapcolor);
            ImGui::ColorPicker4("Skeleton Color", (float*)&config.skeleton);
            ImGui::ColorPicker4("Head Circle Color", (float*)&config.headboxcolor);
            ImGui::PopStyleColor(3);
        }
        ImGui::EndChild();
        break;

    case HEAD_4:
        draw->AddText(fonts::medium, 14.0f, ImVec2(pos.x + 25, pos.y + 60), ImColor(1.0f, 1.0f, 1.0f, 0.6f), "Configs");
        ImGui::SetCursorPos({ 25, 85 });
        ImGui::BeginChild("##container6", ImVec2(240, 350), false, ImGuiWindowFlags_NoScrollbar); {

        }
        ImGui::EndChild();
        break;
    }
}