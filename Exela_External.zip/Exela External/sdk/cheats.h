﻿#include "structs_funcs.h"

int S_width = GetSystemMetrics(SM_CXSCREEN);
int S_height = GetSystemMetrics(SM_CYSCREEN);

float LAphlth;

uintptr_t LAp_rot;

uintptr_t LAppwn;
bool hitsound;

std::string response;

namespace LAGMMEEE
{

	void qweqweqweqweqwe()
	{
		ImGuiIO& io = ImGui::GetIO();
		ImFont* font = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\tahoma.ttf ", 14);
		static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_16_FA, 0 };
		ImFontConfig icons_config; icons_config.MergeMode = true; icons_config.PixelSnapH = true;
		ImFont* FontAwesome = io.Fonts->AddFontFromMemoryCompressedTTF(fa6_solid_compressed_data, fa6_solid_compressed_size, 14.f, &icons_config, icons_ranges);
		ImFont* FontAwesomeBig = io.Fonts->AddFontFromMemoryCompressedTTF(fa6_solid_compressed_data, fa6_solid_compressed_size, 19.f, nullptr, icons_ranges);
		ImFont* TitleFont = io.Fonts->AddFontFromMemoryCompressedTTF(trebucbd_compressed_data, trebucbd_compressed_size, 30, nullptr, io.Fonts->GetGlyphRangesDefault());
		ImFontConfig font_config;
		font_config.PixelSnapH = false;
		font_config.OversampleH = 5;
		font_config.OversampleV = 5;
		font_config.RasterizerMultiply = 1.2f;

		static const ImWchar ranges[] =
		{
			0x0020, 0x00FF, // Basic Latin + Latin Supplement
			0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
			0x2DE0, 0x2DFF, // Cyrillic Extended-A
			0xA640, 0xA69F, // Cyrillic Extended-B
			0xE000, 0xE226, // icons
			0,
		};

		font_config.GlyphRanges = ranges;

		fonts::medium = io.Fonts->AddFontFromMemoryTTF(InterMedium, sizeof(InterMedium), 15.0f, &font_config, ranges);
		fonts::semibold = io.Fonts->AddFontFromMemoryTTF(InterSemiBold, sizeof(InterSemiBold), 17.0f, &font_config, ranges);

		fonts::logo = io.Fonts->AddFontFromMemoryTTF(catrine_logo, sizeof(catrine_logo), 17.0f, &font_config, ranges);

			while (true)
			{
				//Sleep(5);

				world = lexemveread<uintptr_t>(lexemvevirtualaddy + 0x60);
				world = check::validate_pointer(world);
				if (!world) continue;

				game_instance = lexemveread2<uintptr_t>(world + 0x1A0);//offset 0x1a0
				if (!game_instance) continue;

				persistent_level = lexemveread2<uintptr_t>(world + 0x38);
				persistent_level = check::validate_pointer(persistent_level);
				if (!persistent_level) continue;

				uintptr_t local_players = lexemveread2<uintptr_t>(game_instance + 0x40);//offset 0x40
				if (!local_players) continue;

				local_player = lexemveread2<uintptr_t>(local_players);
				if (!local_player) continue;

				Sleep(500);

				LAPNT::player_controller = lexemveread2<uintptr_t>(local_player + 0x38);

				cntrlrttn = lexemveread<fvector>(LAPNT::player_controller + 0x448);

				LAppwn = lexemveread2<DWORD_PTR>(LAPNT::player_controller + 0x468);
				playerstate = lexemveread2<uintptr_t>(LAppwn + 0x3f8);//offset
				teamComponent = lexemveread2<uintptr_t>(playerstate + 0x630);//offset
				teamID = lexemveread2<int>(teamComponent + 0xf8);


				uintptr_t local_pawn = lexemveread2<uintptr_t>(LAPNT::player_controller + 0x468);

				LAPNT::local_pawn = local_pawn;

				LAPNT::camera_manager = lexemveread2<uintptr_t>(LAPNT::player_controller + 0x480);//offsets player_camera 0x478
				LAPNT::camera_position = lexemveread<fvector>(LAPNT::camera_manager + 0x1280);


				uintptr_t actor_array = lexemveread2<uintptr_t>(persistent_level + 0xa0);//offset 0xa0
				if (!actor_array) continue;

				actor_count = lexemveread2<INT32>(persistent_level + 0xa8);
				if (!actor_count) continue;


				for (int x = 0; x < actor_count; x++)
				{

					LApactr = lexemveread2<uintptr_t>(actor_array + (x * 0x8));
					if (!LApactr) continue;

					INT32 unique_id = lexemveread2<INT32>(LApactr + 0x38);
					if (unique_id != 18743553) continue;

					uintptr_t mesh = lexemveread2<uintptr_t>(LApactr + 0x438);//offset 0x430
					if (!mesh) continue;

					LAp_rot = lexemveread2<uintptr_t>(LApactr + 0x238);// offsets 0x230
					if (!LAp_rot) continue;

					uintptr_t damage_handler = lexemveread2<uintptr_t>(LApactr + 0xa08);
					if (!damage_handler) continue;

					LAphlth = lexemveread2<float>(damage_handler + 0x1B0);

					uintptr_t playerstate = lexemveread2<uintptr_t>(LApactr + 0x3F8);
					uintptr_t team_component = lexemveread2<uintptr_t>(playerstate + 0x630);
					int team_id = lexemveread2<int>(team_component + 0xF8);
					if (team_id == teamID) continue;

					if (LAphlth <= 0) continue;

					uintptr_t bone_array = lexemveread2<uintptr_t>(mesh + 0x5D8);
					if (!bone_array) continue;

					INT32 bone_count = lexemveread2<INT32>(mesh + 0x5E0);
					if (!bone_count) continue;


					{
						uintptr_t actor;
						uintptr_t mesh;
						uintptr_t bone_array;
						uintptr_t root_component;
						uintptr_t damage_handler;

						INT32 bone_count;
						INT32 ammo_count;

						std::string weapon_name;
						std::string agent_name;
						std::string player_name;

						float distance;
						float health;
						float shield;

						bool is_valid;
						bool is_damage_handler_guarded;
						bool is_mesh_guarded;
					};
					uintptr_t for_mesh, for_actor = 0x1;
					bool is_damage_handler_guarded = false, is_mesh_guarded = false;
					//define player
					LAPLYR this_player{
						for_actor, //guarded region ptr
						for_mesh, //guarded region ptr
						LApactr,
						mesh,
						bone_array,
						LAp_rot,
						damage_handler,
						bone_count,
						0, //ammo count
						"", //weapon name
						"", //agent name
						"", //player name
						0.f, //distance
						LAphlth, //health
						0.f, //shleid
						true,
						is_damage_handler_guarded,
						is_mesh_guarded
					};

					//pushback player (if he isnt in the actor list yet)
					if (!player_pawns.empty()) {
						auto found_player = std::find(player_pawns.begin(), player_pawns.end(), this_player);
						if (found_player == player_pawns.end())
						{
							player_pawns.push_back(this_player);
						}


					}
					else
					{
						player_pawns.push_back(this_player);
					}

				}
				Sleep(500);
			}
	}

#define DegreeToRadian( Degree )	( ( Degree ) * ( M_PI / 180.0f ) )



	static fvector pRadar;


	Vector2 WorldRadar(fvector srcPos, fvector distPos, float yaw, float radarX, float radarY, float size)
	{
		auto cosYaw = cos(DegreeToRadian(yaw));
		auto sinYaw = sin(DegreeToRadian(yaw));

		auto deltaX = srcPos.x - distPos.x;
		auto deltaY = srcPos.y - distPos.y;

		auto locationX = (float)(deltaY * cosYaw - deltaX * sinYaw) / 45.f;
		auto locationY = (float)(deltaX * cosYaw + deltaY * sinYaw) / 45.f;

		if (locationX > (size - 2.f))
			locationX = (size - 2.f);
		else if (locationX < -(size - 2.f))
			locationX = -(size - 2.f);

		if (locationY > (size - 6.f))
			locationY = (size - 6.f);
		else if (locationY < -(size - 6.f))
			locationY = -(size - 6.f);

		return Vector2((int)(-locationX + radarX), (int)(locationY + radarY));
	}
	void DrawRadar(fvector EntityPos)
	{
		auto radar_posX = pRadar.x + 135;
		auto radar_posY = pRadar.y + 135;
		uint64_t LocalRootComp = lexemveread2<uint64_t>(LAPNT::local_pawn + 0x238);
		fvector LocalPos = lexemveread<fvector>(LocalRootComp + 0x164);
		auto Radar2D = WorldRadar(LocalPos, EntityPos, LACAMRA::rotation.y, radar_posX, radar_posY, 135.f);
		ImVec4 S4 = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
		DrawCircleRadar(Radar2D.x, Radar2D.y, 4, S4); //R1);
	}

	auto LATMID(uintptr_t APawn) -> int {
		auto PlayerState = lexemveread<uintptr_t>(APawn + 0x3F8);//offset
		auto TeamComponent = lexemveread<uintptr_t>(PlayerState + 0x630);//offset
		return lexemveread<int>(TeamComponent + 0xF8);//offset
	};

	void LAPTLARE()
	{
		auto ViewInfo = lexemveread<FMinimalViewInfo>(LAPNT::camera_manager + 0x1FB0);
		LACAMRA::location = ViewInfo.Location;
		LACAMRA::rotation = ViewInfo.Rotation;
		LACAMRA::fov = ViewInfo.FOV;
	}

	void DrawFilledRect(int x, int y, int w, int h, RGBA* color)
	{
		ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), ImGui::ColorConvertFloat4ToU32(ImVec4(color->R / 255.0, color->G / 153.0, color->B / 51.0, color->A / 255.0)), 0, 0);
	}

	auto DrawHealthBar(fvector RootPositionn, float Width, float Height, float Health, float RelativeDistance) -> void
	{
		auto HPBoxWidth = 1 / RelativeDistance;

		auto HPBox_X = RootPositionn.x - Width / 2 - 5 - HPBoxWidth;
		auto HPBox_Y = RootPositionn.y - Height / 2 + (Height - Height * (Health / 100));

		int HPBoxHeight = Height * (Health / 100);

		if (Health >= 80)
		{
			DrawFilledRect(HPBox_X, HPBox_Y, HPBoxWidth, HPBoxHeight, &Col.green);
		}
		else
		{
			if (Health <= 80 && Health >= 50)
			{
				DrawFilledRect(HPBox_X, HPBox_Y, HPBoxWidth, HPBoxHeight, &Col.yellow);
			}

			if (Health <= 50 && Health >= 30)
			{
				DrawFilledRect(HPBox_X, HPBox_Y, HPBoxWidth, HPBoxHeight, &Col.orange);
			}

			if (Health <= 30)
			{
				DrawFilledRect(HPBox_X, HPBox_Y, HPBoxWidth, HPBoxHeight, &Col.red);
			}
		}

		DrawRect(HPBox_X - 1, HPBox_Y - 1, HPBoxWidth + 2, HPBoxHeight + 2, &Col.black, 1);
	}

	auto Draw2DBox(fvector RootPositionn, float Width, float Height, ImColor Color) -> void
	{
		DrawNormalBox(RootPositionn.x - Width / 2, RootPositionn.y - Height / 2, Width, Height, 0.7f, Color);
	}

	auto RelativeLocation(uintptr_t APawn) -> fvector {
		auto RootComponent = lexemveread<uintptr_t>(APawn + 0x238);
		return lexemveread<fvector>(RootComponent + 0x164);
	}

	auto DrawLine(const ImVec2& x, const ImVec2 y, ImU32 color, const FLOAT width) -> void
	{
		ImGui::GetForegroundDrawList()->AddLine(x, y, color, width);
	}

	void DrawCircleFilled(int x, int y, int radius, ImVec4 color, float segments)
	{
		ImGui::GetForegroundDrawList()->AddCircleFilled(ImVec2(x, y), radius, ImGui::ColorConvertFloat4ToU32(color), segments);
	}

	fvector bone, head, chest, pelvis;

	void random_aimbonee()
	{
		while (true)
		{
			bone = head;
			std::this_thread::sleep_for(std::chrono::milliseconds(3));

			bone = chest;
			std::this_thread::sleep_for(std::chrono::milliseconds(3));

			bone = pelvis;
			std::this_thread::sleep_for(std::chrono::milliseconds(3));
		}
	}

	void LARNDRPLYRSS()
	{
		LAPTLARE();

			int closestplayer = 1337;
			float closest_distance = FLT_MAX;

			for (int x = 0; x < player_pawns.size(); x++)
			{
				LAPLYR this_player = player_pawns[x];

				if (player_pawns.empty()) {
					return;
				}

				float health = 0;
				health = lexemveread<float>(this_player.damage_handler + 0x1B0);

				if (health <= 0.f || health > 999.f)
				{
					player_pawns[x].is_valid = false;
				}

				if (!this_player.is_valid)
				{
					auto erase_player = std::find(player_pawns.begin(), player_pawns.end(), this_player);
					player_pawns.erase(erase_player);
					continue;
				}

				uintptr_t playerstate = lexemveread2<uintptr_t>(this_player.actor + 0x3F8);
				uintptr_t team_component = lexemveread2<uintptr_t>(playerstate + 0x630);
				int team_id = lexemveread2<int>(team_component + 0xF8);
				if (team_id == teamID) continue;

				int actors_int = lexemveread2<int>(this_player.actor + 0x38);

				if (actors_int != 18743553) continue;

				bool active = is_dormant(this_player);
				if (config.player_ignore_dormant && !active)
					continue;

				fvector zero = LABNMTRX(0, this_player);
				fvector head = LABNMTRX(8, this_player);

				fvector zero_r = fvector(zero.x, zero.y, zero.z - 5);

				fvector vBaseBoneOut = w2s(fvector(zero.x, zero.y, zero.z));
				fvector vBaseBoneOut2 = w2s(fvector(zero.x, zero.y, zero.z - 15));

				fvector vHeadBoneOut = w2s(fvector(head.x, head.y, head.z));

				fvector vHeadBoneOut2 = w2s(fvector(head.x, head.y, head.z + 15));
				fvector vHeadBoneOut3 = w2s(fvector(head.x, head.y, head.z + 40));

				float BoxHeight = abs(vHeadBoneOut2.y - vBaseBoneOut.y);
				float BoxWidth = BoxHeight * 0.55;

				fvector head_r = fvector(head.x, head.y, head.z + 20);
				fvector head_r_2 = fvector(head.x, head.y, head.z + 30);

				fvector zero_w2s = w2s(zero);
				fvector head_w2s = w2s(head);

				fvector zero_w2s_r = w2s(zero_r);
				fvector head_w2s_r = w2s(head_r);

				fvector head_w2s_r_2 = w2s(head_r_2);

				int Width = GetSystemMetrics(SM_CXSCREEN);
				int Height = GetSystemMetrics(SM_CYSCREEN);

				pRadar.x = (Width / 2) + 550;
				pRadar.y = Width / 2 - Height / 2 - 300;

				auto RelativeLocationn = RelativeLocation(this_player.actor);
				auto RelativePosition = RelativeLocationn - LACAMRA::location;
				auto RelativeDistance = RelativePosition.Length() / 10000 * 2;
				auto RelativeLocationProjected = w2s(RelativeLocationn);

				float distance = LACAMRA::location.distance(zero) / 100.f;

				if (config.distancecontrol && (float)config.max_distance < distance)
					continue;

				int bottom_text_offset = 2;

				if (config.player_healthbar)
				{
					DrawHealthBar(RelativeLocationProjected, BoxWidth, BoxHeight, health, RelativeDistance);
				}
				
				if (config.circlehead == true)
				{
					ImGui::GetForegroundDrawList()->AddCircle(ImVec2(vHeadBoneOut.x, vHeadBoneOut.y), BoxWidth / 5, ImColor(config.headboxcolor), 64, 1.f);
				}
				

				ImVec4 S4 = to_vec4(2, 160, 115, (int)Alpha);

				if (config.radar)
				{

					static ImVec2 radarPosition = ImVec2(pRadar.x, pRadar.y);  // Radar espnin başlangıç konumu

					//if (ImGui::IsMouseDragging(0))  // Fare sol tuşu ile sürükleniyor mu kontrolü
					//{
					//	ImVec2 delta = ImGui::GetIO().MouseDelta;
					//	radarPosition.x += delta.x;
					//	radarPosition.y += delta.y;
					//}

					pRadar.x = radarPosition.x;
					pRadar.y = radarPosition.y;

					if (radartype == 0)
					{
						ImGui::GetForegroundDrawList()->AddRect(ImVec2(pRadar.x, pRadar.y), ImVec2(pRadar.x + 270, pRadar.y + 270), ImGui::ColorConvertFloat4ToU32(ImVec4(255, 255, 255, 255)), 2);
						auto radar_posX = pRadar.x + 135;
						auto radar_posY = pRadar.y + 135;
						//DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX, radar_posY + 135), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						//DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX, radar_posY - 135), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX + 135, radar_posY), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX - 135, radar_posY), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						DrawCircleFilled(radar_posX + 1, radar_posY + 1, 3, S4, 10);
					}

					if (radartype == 1)
					{
						float radius = 135.0f;
						float radar_posX = pRadar.x + radius;
						float radar_posY = pRadar.y + radius;

						ImVec2 center(radar_posX, radar_posY);
						ImGui::GetForegroundDrawList()->AddCircle(center, radius, ImGui::ColorConvertFloat4ToU32(ImVec4(255, 255, 255, 255)), 32, 1.0f);

						//DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX, radar_posY + radius), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						//DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX, radar_posY - radius), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX + radius, radar_posY), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						DrawLine(ImVec2(radar_posX, radar_posY), ImVec2(radar_posX - radius, radar_posY), ImGui::ColorConvertFloat4ToU32(ImVec4(236, 236, 236, 255)), 1);
						DrawCircleFilled(radar_posX + 1, radar_posY + 1, 3, S4, 10);
					}

					fvector pos = lexemveread<fvector>(this_player.root_component + 0x164);
					DrawRadar(pos);
				}



				ImGuiIO& io = ImGui::GetIO();
				ImFont* espfont = io.Fonts->AddFontFromFileTTF("C:\Windows\Fonts\Calibri.ttf", 14);
				ImGui::PushFont(espfont);
				ImGui::PopFont();


				/*if (config.agentnames == true)
				{

					int keyy = lexemveread<int>(this_player.actor + 0x18);
					std::string namee = get_fname(keyy);


					if (namee.find("None") != std::string::npos)
					{
						namee = "Lobi";
					}

					if (namee.find("Wushu") != std::string::npos)
					{
						namee = "Jett";
					}

					if (namee.find("Rift") != std::string::npos)
					{
						namee = "Astra";
					}

					if (namee.find("Grenadier") != std::string::npos)
					{
						namee = "Kay/O";
					}

					if (namee.find("Breach") != std::string::npos)
					{
						namee = "Breach";
					}

					if (namee.find("Sarge") != std::string::npos)
					{
						namee = "Brimstone";
					}

					if (namee.find("Deadeye") != std::string::npos)
					{
						namee = "Chamber";
					}

					if (namee.find("Gumshoe") != std::string::npos)
					{
						namee = "Cypher";
					}

					if (namee.find("Killjoy") != std::string::npos)
					{
						namee = "Killjoy";
					}

					if (namee.find("Sprinter") != std::string::npos)
					{
						namee = "Neon";
					}

					if (namee.find("Wraith") != std::string::npos)
					{
						namee = "Omen";
					}

					if (namee.find("Phoenix") != std::string::npos)
					{
						namee = "Phoenix";
					}

					if (namee.find("Clay") != std::string::npos)
					{
						namee = "Raze";
					}

					if (namee.find("Vampire") != std::string::npos)
					{
						namee = "Reyna";
					}

					if (namee.find("Thorne") != std::string::npos)
					{
						namee = "Sage";
					}

					if (namee.find("Guide") != std::string::npos)
					{
						namee = "Skye";
					}

					if (namee.find("Hunter_PC_C") != std::string::npos)
					{
						namee = "Sova";
					}

					if (namee.find("Pandemic") != std::string::npos)
					{
						namee = "Viper";
					}

					if (namee.find("Stealth") != std::string::npos)
					{
						namee = "Yoru";
					}

					if (namee.find("BountyHunter") != std::string::npos)
					{
						namee = "Fade";
					}

					if (namee.find("TrainingBot") != std::string::npos)
					{
						namee = "Bot";
					}

					if (namee.find("AggroBot") != std::string::npos)
					{
						namee = "Gekko";
					}

					if (namee.find("Mage") != std::string::npos)
					{
						namee = "Harbor";
					}

					if (namee.find("Cable") != std::string::npos)
					{
						namee = "Deadlock";
					}

					if (namee.find("Sequoia") != std::string::npos)
					{
						namee = "Iso";
					}

					ImVec2 TextSize2 = ImGui::CalcTextSize(namee.c_str());
					ImVec4 redColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); // RGBA renk bileşenleri (0-1 aralığında)
					ImU32 redColorU32 = ImGui::GetColorU32(redColor);
					bottom_text_offset += 15;
					ImGui::GetForegroundDrawList()->AddText(ImVec2(vHeadBoneOut3.x - (TextSize2.x / 2), vHeadBoneOut3.y + bottom_text_offset), redColorU32, namee.c_str());
				}*/

				if (config.player_box)
				{
					if (config.esptype == 0)
					{
						float BoxHeight = zero_w2s_r.y - head_w2s_r.y;
						float BoxWidth = BoxHeight / 2.f;
						LAPDRWCRNbx(zero_w2s_r.x - (BoxWidth / 2), head_w2s_r.y, BoxWidth, BoxHeight, config.espcolor, 0.6f);
					}

					if (config.esptype == 1)
					{
						//Draw2DBox(RelativeLocationProjected, BoxWidth, BoxHeight, config.espcolor);
						DrawNormalBox(zero_w2s.x - (BoxWidth / 2), head_w2s.y, BoxWidth, BoxHeight, 0.6f, config.espcolor);
					}

					if (config.esptype == 2)
					{
						LAdrw3dbx(zero, fvector(head.x, head.y, head.z + 20), 38, config.espcolor, 0.6f);
					}
				}

				/*if (config.player_skeleton)
				{
					LADRWSKLTN(this_player, config.skeleton, 0.7f);
				}*/


				/*if (config.player_distance)
				{
					char distance_text[256];
					sprintf_s(distance_text, "[ %.fm ]", distance);
					ImVec2 text_size = ImGui::CalcTextSize(distance_text);
					ImGui::GetForegroundDrawList()->AddText(ImVec2(zero_w2s_r.x - (text_size.x / 2), zero_w2s_r.y + bottom_text_offset), ImGui::GetColorU32({ 0.3f, 0.7f, 1.f, 1.f }), distance_text);
					bottom_text_offset += 14;
				}*/

				if (config.player_snapline)
				{
					ImGui::GetForegroundDrawList()->AddLine(ImVec2(LAcenter_x, LAcenter_y * 2), ImVec2(zero_w2s_r.x, zero_w2s_r.y + bottom_text_offset), ImGui::GetColorU32(config.snapcolor), 1.f);
				}

				vis = isVisible(this_player.mesh);

				float delta_x = head_w2s.x - (Width / 2.f);
				float delta_y = head_w2s.y - (Height / 2.f);
				float dist = sqrtf(delta_x * delta_x + delta_y * delta_y);
				float fovdist = CalculateDistance(Width / 2, Height / 2, head_w2s.x, head_w2s.y);
				if ((dist < closest_distance) && fovdist < config.aimbot_fov) {
					closest_distance = dist;
					closestplayer = x;
				}

			}

			if (config.aimenable && !config.rcs && closestplayer != 1337)
			{
				LAPLYR this_player = player_pawns[closestplayer];

				head = LABNMTRX(8, this_player);
				chest = LABNMTRX(6, this_player);
				pelvis = LABNMTRX(3, this_player);


				if (config.aimboness == 0)
				{
					bone = head;
				}

				if (config.aimboness == 1)
				{
					bone = chest;
				}

				if (config.aimboness == 2)
				{
					bone = pelvis;
				}

				fvector rootpos = lexemveread<fvector>(this_player.root_component + 0x164);

				if (bone.z <= rootpos.z)
				{
					return;
				}

				fvector localView = lexemveread<fvector>(LAPNT::player_controller + 0x448);
				fvector vecCaclculatedAngles = fhgfsdhkfshdghfsd205(LACAMRA::location, bone);
				fvector angleEx = CaadadalcAngle(LACAMRA::location, bone);
				fvector fin = fvector(vecCaclculatedAngles.y, angleEx.y, 0);
				fvector delta = fin - localView;
				NormalizeAngles(delta);

				fvector TargetAngle = localView + (delta / config.aimbot_smooth);
				NormalizeAngles(TargetAngle);

				if (GetAsyncKeyState(AimKeyList[config.aimbotkey]) & 0x8000)
				{
					if (config.visiblecheck == true)
					{
						if (vis)
						{
							lxmvwrte<fvector>(LAPNT::player_controller + 0x448, TargetAngle);
						}
					}
					else
					{
						lxmvwrte<fvector>(LAPNT::player_controller + 0x448, TargetAngle);
					}
				}


			}

			if (config.aimenable && config.rcs && closestplayer != 1337)
			{
				LAPLYR this_player = player_pawns[closestplayer];

				head = LABNMTRX(8, this_player);
				chest = LABNMTRX(6, this_player);
				pelvis = LABNMTRX(3, this_player);



				if (config.aimboness == 0)
				{
					bone = head;
				}

				if (config.aimboness == 1)
				{
					bone = chest;
				}

				if (config.aimboness == 2)
				{
					bone = pelvis;
				}

				fvector rootpos = lexemveread<fvector>(this_player.root_component + 0x164);

				if (bone.z <= rootpos.z)
				{
					return;
				}

				fvector localView = lexemveread<fvector>(LAPNT::player_controller + 0x448);
				fvector vecCaclculatedAngles = fhgfsdhkfshdghfsd205(LACAMRA::location, bone);
				fvector angleEx = CaadadalcAngle(LACAMRA::location, bone);
				fvector fin = fvector(vecCaclculatedAngles.y, angleEx.y, 0);
				fvector delta = fin - localView;
				fvector TargetAngle2 = localView + delta;
				Clamp(TargetAngle2);


				if (GetAsyncKeyState(AimKeyList[config.aimbotkey]) & 0x8000)
				{
					if (config.visiblecheck == true)
					{
						if (vis)
						{
							RCS(TargetAngle2, LACAMRA::rotation, config.aimbot_smooth);
						}
					}
					else
					{
						RCS(TargetAngle2, LACAMRA::rotation, config.aimbot_smooth);
					}

				}

				float temp = GetFov(LACAMRA::rotation, vecCaclculatedAngles);

			}

			if (config.aimbot_draw_fov)
			{
				ImGui::GetForegroundDrawList()->AddCircle(ImVec2(LAcenter_x, LAcenter_y), config.aimbot_fov, ImGui::GetColorU32({ 1.f, 1.f, 1.f, 1.f }), 64, 1.f);
			}


	}

	void LARNNDDDRR() {

		ImGui_ImplDX9_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
		ImGui::SetNextWindowSize({ 600, 470 });
		if (GetAsyncKeyState(VK_INSERT) & 1)
			LAMNPON = !LAMNPON;
		if (LAMNPON)
		{
			ImGui::GetIO().MouseDrawCursor = 1;
			if (ImGui::Begin("", NULL, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground))
			{
				bubble();
			}ImGui::End();
			ImGui::PopStyleVar();
			ImGui::EndFrame();
		}
		else
			ImGui::GetIO().MouseDrawCursor = 0;

		LARNDRPLYRSS();
		D3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);

		if (D3dDevice->BeginScene() >= 0) {
			ImGui::Render();
			ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
			D3dDevice->EndScene();
		}
		HRESULT LARSLT = D3dDevice->Present(NULL, NULL, NULL, NULL);

		if (LARSLT == D3DERR_DEVICELOST && D3dDevice->TestCooperativeLevel() == D3DERR_DEVICENOTRESET) {
			ImGui_ImplDX9_InvalidateDeviceObjects();
			D3dDevice->Reset(&d3dpp);
			ImGui_ImplDX9_CreateDeviceObjects();
		}
	}

	void LARNDRLPP() {
		static RECT old_rc;
		ZeroMemory(&LAMSSG, sizeof(MSG));

		while (LAMSSG.message != WM_QUIT)
		{
			if (PeekMessage(&LAMSSG, LAWNDWWW, 0, 0, 0x0001))
			{
				TranslateMessage(&LAMSSG);
				DispatchMessage(&LAMSSG);
			}

			HWND hwnd_active = GetForegroundWindow();

			if (hwnd_active == LAHND) {
				HWND hwndtest = GetWindow(hwnd_active, 3);
				SetWindowPos(LAWNDWWW, hwndtest, 2, 2, -3, -3, 0x0002 | 0x0001);
			}

			RECT rc;
			POINT xy;

			ZeroMemory(&rc, sizeof(RECT));
			ZeroMemory(&xy, sizeof(POINT));
			GetClientRect(LAHND, &rc);
			ClientToScreen(LAHND, &xy);
			rc.left = xy.x;
			rc.top = xy.y;

			ImGuiIO& io = ImGui::GetIO();
			io.ImeWindowHandle = LAHND;
			io.DeltaTime = 1.0f / 60.0f;

			POINT p;
			GetCursorPos(&p);
			io.MousePos.x = p.x - xy.x;
			io.MousePos.y = p.y - xy.y;

			if (GetAsyncKeyState(VK_LBUTTON)) {
				io.MouseDown[0] = true;
				io.MouseClicked[0] = true;
				io.MouseClickedPos[0].x = io.MousePos.x;
				io.MouseClickedPos[0].x = io.MousePos.y;
			}
			else
				io.MouseDown[0] = false;

			if (rc.left != old_rc.left || rc.right != old_rc.right || rc.top != old_rc.top || rc.bottom != old_rc.bottom)
			{
				old_rc = rc;

				LAWidth = rc.right;
				LAHeight = rc.bottom;

				d3dpp.BackBufferWidth = LAWidth;
				d3dpp.BackBufferHeight = LAHeight;
				SetWindowPos(LAWNDWWW, (HWND)0, xy.x + 2, xy.y + 2, LAWidth - 3, LAHeight - 3, 0x0008);
				D3dDevice->Reset(&d3dpp);
			}

			LARNNDDDRR();

		}
		ImGui_ImplDX9_Shutdown();
		ImGui_ImplWin32_Shutdown();
		ImGui::DestroyContext();

		DestroyWindow(LAWNDWWW);
	}

	void LASTRTC() {
		LAHND = FindWindowA(0, _("D3D11TEST"));

		LACRTWND0W();

		LASTRTDRX();

		WTFRWNDW();

		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)qweqweqweqweqwe, NULL, NULL, NULL);

		LARNDRLPP();
		LASTPRNDR();
	}
}
